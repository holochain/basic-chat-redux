self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "249ea263672272de33e06eea01b30e34",
    "url": "/index.html"
  },
  {
    "revision": "96c5da1dc3e7ccb752f2",
    "url": "/static/css/main.2ae4f6c2.chunk.css"
  },
  {
    "revision": "90a4215f0214fd22d492",
    "url": "/static/js/2.718db055.chunk.js"
  },
  {
    "revision": "5b8779f3b76c71dbdf14eb9d549ebd87",
    "url": "/static/js/2.718db055.chunk.js.LICENSE"
  },
  {
    "revision": "96c5da1dc3e7ccb752f2",
    "url": "/static/js/main.d6508d24.chunk.js"
  },
  {
    "revision": "35895a34f8bfdd145f36",
    "url": "/static/js/runtime-main.bc357fdb.js"
  }
]);